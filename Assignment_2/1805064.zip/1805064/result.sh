flex -o 1805064.cpp 1805064.l
g++ 1805064.cpp -lfl -o 1805064.out
./1805064.out input.txt
rm 1805064.cpp 1805064.out
